import json
import random


def load_quiz_data(file_path):
    """Načíta JSON údaje o kvíze zo súboru."""
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            return json.load(file)
    except FileNotFoundError:
        print(f"Súbor '{file_path}' nebol nájdený.")
        exit()
    except json.JSONDecodeError:
        print(f"Súbor '{file_path}' obsahuje neplatný JSON.")
        exit()


def shuffle_options(question_data):
    """Zmieša možnosti a zistí index správnej odpovede."""
    options = question_data["options"]
    correct_answer = question_data["correct_answer"]

    shuffled_options = random.sample(options, len(options))
    correct_index = shuffled_options.index(correct_answer)

    return shuffled_options, correct_index


def run_quiz(quiz_data):
    """Spustí kvíz na základe načítaných údajov."""
    score = 0
    print("Vitajte v kvíze o špecifikácii požiadaviek!")
    print("Odpovedajte výberom čísla (1-4).\n")

    # Náhodne zamieša otázky
    random.shuffle(quiz_data["questions"])

    for idx, question_data in enumerate(quiz_data["questions"], start=1):
        print(f"Otázka {idx}: {question_data['question']}")

        # Zamieša možnosti
        shuffled_options, correct_index = shuffle_options(question_data)
        for i, option in enumerate(shuffled_options, start=1):
            print(f"  {i}. {option}")

        while True:
            try:
                user_answer = int(input("Vaša odpoveď: "))
                if 1 <= user_answer <= len(shuffled_options):
                    break
                else:
                    print("Zadajte platné číslo možnosti.")
            except ValueError:
                print("Zadajte číslo možnosti.")

        if user_answer - 1 == correct_index:
            print("Správne!")
            score += 1
        else:
            print("Nesprávne.")
            print(f"Správna odpoveď: {question_data['correct_answer']}")
        print(f"Vysvetlenie: {question_data['explanation']}\n")

    print(f"Dosiahli ste skóre {score}/{len(quiz_data['questions'])}. Ďakujeme za účasť!")


if __name__ == "__main__":
    # Zmeňte cestu k JSON súboru, ak je v inom adresári
    file_path = "data/relialableSystems.json"
    quiz_data = load_quiz_data(file_path)
    run_quiz(quiz_data)
